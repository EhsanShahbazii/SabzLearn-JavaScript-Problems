const $ = document;
const todayTimeBox = $.getElementsByClassName("today_timeBox"),
  dropDownLink = $.getElementsByClassName("dropDown_link"),
  dropDownLinks = $.getElementsByClassName("dropDown_links"),
  scrollBar = $.getElementsByClassName("scroll-prograss"),
  copyWrite = $.querySelectorAll("#copy-write"),
  topSlider = $.getElementsByClassName("top-slider")[0],
  nextSliderBtn = $.getElementById("nextSlider"),
  prevSliderBtn = $.getElementById("prevSlider"),
  iranianMovie = $.getElementsByClassName("im"),
  iranianSerial = $.getElementsByClassName("is"),
  foreignMovie = $.getElementsByClassName("fm"),
  foreignSerial = $.getElementsByClassName("fs"),
  indexMovies = $.getElementsByClassName("index_movies")[0],
  mostViews = $.getElementsByClassName("most_views"),
  searchInput = $.getElementsByClassName("search"),
  searchBtn = $.getElementsByClassName("searchBtn"),
  bread = $.getElementsByClassName("bread"),
  viTitle = $.getElementsByClassName("vi_title")[0],
  viDate = $.getElementsByClassName("vi_date")[0],
  viImage = $.getElementsByClassName("vi_image")[0],
  viDetails = $.getElementsByClassName("vi_details")[0],
  viKeys = $.getElementsByClassName("vi_keys")[0],
  viCommentCount = $.getElementsByClassName("vi_comment_count")[0];

// show live today time (01.)
[...todayTimeBox].map((box) => (box.innerText = todayTime()));

// active drop down link (02.)
[...dropDownLink].map((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault(); // to prevent loading of page
    [...dropDownLinks].map((nav) => nav.classList.toggle("active")); // toggle show/hide of dropBox
  });
});

// make slider dynamic (03.)
getAllMovies().then((movies) => {
  // get all movies data
  let allMovie = [], // store all movie elements
    currentIndex = 0;
  [...movies].map((movie) => {
    // create element from movie detail
    allMovie.push(`<div class="d-flex flex-row-reverse align-items-center slide1">
  <div class="top-left-slider col-8">
    <h6 class="pt-4" id="titleSlider">${movie.title}</h6>
    <p class="m-0" id="descSlider">${movie.summary}</p>
    <div class="data pb-4">
      <i class="fa fa-calendar"></i>
      <div class="">
        <p class="m-0">انتشار :</p>
        <p class="m-0" id="dataSlider">${movie.date}</p>
      </div>
    </div>
  </div>
  <div class="top-right-slider col-4">
    <img
      src=${movie.image}
      alt=${movie.title}
      class="w-100 h-100"
      id="imgSlider"
    />
  </div>
</div>`);

    // allMovie = allMovie.slice(0, 4);
  });

  const loadMovie = () => (topSlider.innerHTML = allMovie[currentIndex]); // load movie detail

  loadMovie(); // load first movie when page load at first

  // add event listener for next slide button
  nextSliderBtn.addEventListener("click", () => {
    currentIndex >= allMovie.length - 1 ? (currentIndex = 0) : currentIndex++; // make rotate function
    loadMovie(); // load currentIndex movie detail in slider
  });
  // add event listener for previous slide button
  prevSliderBtn.addEventListener("click", () => {
    currentIndex <= 0 ? (currentIndex = allMovie.length - 1) : currentIndex--; // make rotate function
    loadMovie(); // load currentIndex movie detail in slider
  });
});

// handle the scroll progress part (04.)
[...scrollBar].map((item) => {
  /*
   * we can handle this progress bar with two things:
   * first: window.pageYOffset => return how much user scroll the window
   * second: $.body.offsetHeight => return all the height of window
   * second: window.innerHeight => return the innerPart of window
   * we can minus first and second part and get ratio and just multiply in 100 to get percent
   */
  window.onscroll = () =>
    (item.style.width = `${
      (window.pageYOffset / ($.body.offsetHeight - window.innerHeight)) * 100
    }%`);
});

// add type writer effect for footer text (05.)
[...copyWrite].map((type) => {
  // create Typewriter obj and initialize it
  let typewriter = new Typewriter(type, {
    loop: true, // for make infinitive of effect
    delay: 120,
  });
  typewriter
    .pauseFor(1000)
    .typeString("این قالب صرفا جهت نمونه کار است")
    .pauseFor(2000)
    .start();
});

// show count of movies in vary category dynamic (06.)
// count of iranian movies
getAllMovieCategory("im").then((movies) =>
  [...iranianMovie].map((box) => (box.innerText = movies.length))
);
// count of iranian serial
getAllMovieCategory("is").then((movies) =>
  [...iranianSerial].map((box) => (box.innerText = movies.length))
);
// count of foreign movies
getAllMovieCategory("fm").then((movies) =>
  [...foreignMovie].map((box) => (box.innerText = movies.length))
);
// count of foreign serials
getAllMovieCategory("fs").then((movies) =>
  [...foreignSerial].map((box) => (box.innerText = movies.length))
);

// show best and most views of movies
getBestMovies().then((movies) => {
  [...mostViews].map((box) => {
    [...movies].map((movie) => {
      let template = `<li>
      <div class="visited-right">
        <img src=${movie.landImage} alt=${movie.title} width="150px" />
      </div>
      <div class="visited-details">
        <p class="m-0">${movie.title}</p>
        <div>
          <p>انتشار :</p>
          <p>${movie.date}</p>
        </div>
      </div>
    </li>`;
      box.innerHTML += template;
    });
  });
});

// show newest movie & serial in index page (07.)

let newestMovies = getAllMovies().then((movies) => {
  let data = movies.slice(0, 5); // the 5 newest movie or serial split it
  data.map((movie) => {
    let template = `<div class="bottom-archive px-2 py-2 border-bottom">
    <div class="film-item d-flex align-items-center justify-content-between col-12 p-0">
      <div class="rounded-sm col-4 p-0 overflow-hidden mr-2 d-none d-md-block">
        <img
          src=${movie.landImage}
          alt=""
          width="100%"
          height="100%"
        />
      </div>
      <div class="film-item-details d-flex flex-column align-items-start justify-content-center px-1 px-md-4 col-12 col-md-8">
        <div class="film-item-title d-flex align-items-center justify-content-between w-100">
          <h6 class="mt-2">${movie.title}</h6>
          <div class="film-item-date d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center justify-content-between">
              <i class="fa fa-calendar"></i>
              <p class="m-0">تاریخ انتشار :</p>
            </div>
            <p class="m-0">${movie.date}</p>
          </div>
        </div>
        <div class="">
          <p class="m-0 text-right">${movie.summary}</p>
        </div>
        <div class="align-self-end">
          <button class="btn btn-warning btn-sm text-dark">
            مشاهده و خرید
          </button>
        </div>
      </div>
    </div>
  </div>`;
    indexMovies.innerHTML += template; // load top 5 in index movie part
  });
});

// todo global search in all pages and data of site (08.)
// [...searchBtn].map((btn, index) => {
//   btn.addEventListener("click", () => {
//     location.replace("../single.html");
//     let query = searchInput[index].value,
//       data = globalSearch(query);
//     data.then((res) => {
//       viTitle.innerHTML = res[0].title;
//     });
//   });
// });

// todo bread crumb handler for pages
// [...bread].map((box) => {
//   let template = `<nav>
//   <ul class="breadcrumb bg-white border text-secondary text-right d-flex flex-row-reverse justify-content-end">
//     <li class="breadcrumb-item active">
//       <a href="#" class="text-decoration-none text-secondary">ساخت ایران فصل سه</a>
//     </li>
//     <li class="breadcrumb-item active">
//       <a href="../archive.html" class="text-decoration-none text-secondary">سریال ایرانی</a>
//     </li>
//     <li class="breadcrumb-item">
//       <a href="../archive.html" class="text-decoration-none text-secondary">فیلم سریال</a>
//     </li>
//     <li class="breadcrumb-item">
//       <a href="../index.html" class="text-decoration-none text-secondary">خانه</a>
//     </li>
//   </ul>
// </nav>`;
// });

// login and sign up user handler (10.)
// const registerEmail = $.getElementsByClassName("reg_email")[0],
//   registerPhone = $.getElementsByClassName("reg_phone")[0],
//   registerPassword = $.getElementsByClassName("reg_password")[0],
//   registerRepeatPassword = $.getElementsByClassName("reg_repeat_password")[0],
//   registerSubmitBtn = $.getElementsByClassName("reg_submit")[0];

// const loginEmail = $.getElementsByClassName("log_email")[0],
//   loginPassword = $.getElementsByClassName("log_password")[0],
//   loginSubmitBtn = $.getElementById("log_submit");

// registerSubmitBtn.addEventListener("click", (e) => {
//   e.preventDefault();
//   if (registerEmail.value == null || registerEmail.value == "") {
//     alert("please enter your email");
//   } else if (
//     registerPhone.value == null ||
//     registerPhone.value == "" ||
//     registerPhone.value.length < 11
//   ) {
//     alert("please enter your phone number");
//   } else if (
//     registerPassword.value !== registerRepeatPassword.value ||
//     registerPassword.value.length < 7
//   ) {
//     alert("password not correct");
//   } else {
//     signUpUser(
//       registerEmail.value,
//       registerPhone.value,
//       registerPassword.value
//     );
//     alert("your sign up is successful!");
//   }
// });

// loginSubmitBtn.addEventListener("click", (e) => {
//   e.preventDefault();
//   // if (loginEmail.value == null || loginEmail.value == "") {
//   //   alert("please enter your email");
//   // } else if (
//   //   loginPassword.value == null ||
//   //   loginPassword.value == "" ||
//   //   loginPassword.value.length < 7
//   // ) {
//   //   alert("please enter your phone number");
//   // } else {
//   //   loginEmail().then((user) => {
//   //     if (
//   //       user.email == loginEmail.value &&
//   //       user.password == loginPassword.value
//   //     ) {
//   //       alert("your login is successful!");
//   //     } else {
//   //       alert("email or password not correct!");
//   //     }
//   //   });
//   // }
//   console.log(1);
// });

// load movie in archives
let archives = $.getElementsByClassName("archives")[0];
getAllMovies().then((movies) => {
  [...movies].map((movie) => {
    let template = `<div class="">
    <div class="bottom-archive px-2 py-2 border-bottom">
      <div
        class="film-item d-flex align-items-center justify-content-between col-12 p-0"
      >
        <div
          class="rounded-sm col-4 p-0 overflow-hidden mr-2 d-none d-md-block"
        >
          <img
            src=${movie.landImage}
            alt=""
            width="100%"
            height="100%"
            class=""
          />
        </div>
        <div
          class="film-item-details d-flex flex-column align-items-start justify-content-center px-1 px-md-4 col-12 col-md-8"
        >
          <div
            class="film-item-title d-flex align-items-center justify-content-between w-100"
          >
            <h6 class="mt-2">${movie.title}</h6>
            <div
              class="film-item-date d-flex align-items-center justify-content-between"
            >
              <div
                class="d-flex align-items-center justify-content-between"
              >
                <i class="fa fa-calendar"></i>
                <p class="m-0">تاریخ انتشار :</p>
              </div>
              <p class="m-0">${movie.date}</p>
            </div>
          </div>
          <div class="">
            <p class="m-0 text-right">
              ${movie.summary}
            </p>
          </div>
          <div class="align-self-end">
            <button class="btn btn-warning btn-sm text-dark">
              مشاهده و خرید
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
    archives.innerHTML += template;
  });
});
