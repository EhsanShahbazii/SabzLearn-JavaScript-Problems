// return today persian date (for example 1402/1/14)
const todayTime = () => new Date().toLocaleDateString("fa-IR");

// get all movies data
const getAllMovies = async () => {
  const response = await fetch("http://localhost:3000/movies");
  return response.json();
};

// get all movie witch same category
const getAllMovieCategory = async (category) => {
  const response = await fetch(
    `http://localhost:3000/movies?category=${category}`
  );
  return response.json();
};

// get the best movie & serial
const getBestMovies = async () => {
  const response = await fetch("http://localhost:3000/movies?star=4&star=5");
  return response.json();
};

// global search engine in site
const globalSearch = async (query) => {
  const response = await fetch(`http://localhost:3000/movies?q=${query}`);
  return response.json();
};

// sign up a new user in data base
const signUpUser = async (email, phone, password) => {
  let user = {
    id: 1,
    email,
    password,
    phone,
  };
  const response = await fetch("http://localhost:3000/user", {
    method: "POST",
    headers: {
      "Content-Type": "Application/json",
    },
    body: JSON.stringify(user),
  });
  return response;
};

// login user true handler
const loginUser = async () => {
  const response = await fetch("http://localhost:3000/user");
  return response.json();
};
