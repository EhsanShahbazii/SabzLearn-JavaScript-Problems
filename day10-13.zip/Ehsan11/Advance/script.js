let input = prompt("Enter array like that (2,4,7,5): ");
let arr = input.split(",");

const maximum = arr.reduce((a, b) => Math.max(a, b), -Infinity);
const minimum = arr.reduce((a, b) => Math.min(a, b), +Infinity);

let min = minimum,
  max = maximum;

const checkVal = (num) => {
  let i;
  for (i = 0; i < arr.length; i++) {
    if (Number(arr[i]) == num) return true;
  }
  return false;
};

const generateSeries = (min, max) => {
  let result = [],
    i;
  for (i = min; i <= max; i++) {
    if (!checkVal(i)) result.push(i);
  }
  return result;
};

alert(generateSeries(min, max));
