let input = Number(prompt("Enter your number:"));

const digitCount = (num) => {
  let count = 0;
  while (num > 1) {
    count++;
    num /= 10;
  }
  return count;
};

const reverseNumber = (num) => {
  let result = 0,
    i,
    numb = Math.abs(num),
    digits = digitCount(numb);
  for (i = 0; i < digits; i++) {
    result += numb % 10;
    if (i + 1 !== digits) result *= 10;
    numb = Math.floor(numb / 10);
  }
  return result;
};

alert(reverseNumber(input));
