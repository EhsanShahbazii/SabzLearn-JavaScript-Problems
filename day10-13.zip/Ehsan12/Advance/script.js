const recordBtn = document.querySelector(".record"),
  stopBtn = document.querySelector(".stop"),
  soundsContainer = document.querySelector(".soundsContainer"),
  mainSection = document.querySelector(".main");

stopBtn.disabled = true;
let audioCtx;

if (navigator.mediaDevices.getUserMedia) {
  const constraints = { audio: true };
  let chunks = [];

  let onSuccess = (stream) => {
    const mediaRecorder = new MediaRecorder(stream);
    visualize(stream);

    recordBtn.onclick = () => {
      mediaRecorder.start();
      recordBtn.style.background = "red";
      stopBtn.disabled = false;
      recordBtn.disabled = true;
    };

    stopBtn.onclick = () => {
      mediaRecorder.stop();
      recordBtn.style.background = "";
      recordBtn.style.color = "";
      stopBtn.disabled = true;
      recordBtn.disabled = false;
    };

    mediaRecorder.onstop = () => {
      const clipContainer = document.createElement("article"),
        audio = document.createElement("audio");

      clipContainer.classList.add("clip");
      audio.setAttribute("controls", "");
      clipContainer.appendChild(audio);
      soundsContainer.appendChild(clipContainer);

      audio.controls = true;
      const blob = new Blob(chunks, { type: "audio/ogg; codecs=opus" });
      chunks = [];
      const audioURL = window.URL.createObjectURL(blob);
      audio.src = audioURL;
    };

    mediaRecorder.ondataavailable = (e) => {
      chunks.push(e.data);
    };
  };

  navigator.mediaDevices.getUserMedia(constraints).then(onSuccess);
} else console.log("not supported!");

visualize = (stream) => {
  if (!audioCtx) audioCtx = new AudioContext();
  const source = audioCtx.createMediaStreamSource(stream),
    analyser = audioCtx.createAnalyser();
  analyser.fftSize = 2048;
  source.connect(analyser);
};
