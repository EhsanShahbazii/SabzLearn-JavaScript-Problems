const preview = document.querySelector("#preview"),
  previewScale = document.querySelector("#preview-scale"),
  previewFlip = document.querySelector("#preview-flip"),
  brightnessSlider = document.querySelector("#brightness"),
  brightnessSliderValue = document.querySelector("#brightness-value"),
  rotateSlider = document.querySelector("#rotate"),
  rotateSliderValue = document.querySelector("#rotate-value");

const handleRotate = () => {
  const rotate = rotateSlider.value;
  rotateSliderValue.innerText = rotate;

  let scaleRotate = (
    Math.abs(Math.sin(`${rotate}`)) + Math.abs(Math.cos(`${rotate}`))
  ).toFixed(5);
  preview.style.transform = `scale(${scaleRotate})`;
  preview.style.transform += `rotate(${rotate}deg)`;
};

const handleBrightness = () => {
  const brightness = brightnessSlider.value;
  brightnessSliderValue.innerText = brightness;

  preview.style.filter = `brightness(${brightness})`;
};

const handleFilter = (e) => {
  const { target } = e;
  const { id: filter } = target;
  let fil = "";

  switch (filter) {
    case "grayscale":
      fil = "grayscale(1)";
      break;
    case "sepia":
      fil = "sepia(1)";
      break;
    case "invert":
      fil = "invert(1)";
      break;
    case "blur":
      fil = "blur(2px)";
      break;
    case "contrast":
      fil = "contrast(2)";
      break;
    case "saturate":
      fil = "saturate(2)";
      break;
    case "hue-rotate":
      fil = "hue-rotate(90deg)";
      break;
    default:
      fil = "none";
  }

  preview.style.filter = fil;
};

let ver = -1,
  hor = -1;
const handleFlip = (flip) => {
  if (flip === "vertical") {
    preview.style.transform = `scaleY(${ver})`;
    ver *= -1;
  } else {
    preview.style.transform = `scaleX(${hor})`;
    hor *= -1;
  }
};

const handleMouseEnter = () => {
  preview.style.transform += "scale(2)";
};

const handleMouseLeave = () => {
  preview.style.transform = "scale(1)";
};

const handleMouseMove = (e) => {
  const imageWidth = previewScale.offsetWidth,
    imageHeight = previewScale.offsetHeight,
    imageOffsetTop = previewScale.offsetTop,
    imageOffsetLeft = previewScale.offsetLeft,
    pageX = e.pageX,
    pageY = e.pageY;

  preview.style.transformOrigin = `${pageX - imageOffsetLeft}px ${
    pageY - imageOffsetTop
  }px`;
};
