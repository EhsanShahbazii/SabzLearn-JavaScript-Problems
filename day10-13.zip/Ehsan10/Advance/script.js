//solution 1
let input = Number(prompt("Enter your number:"));

const digitCount = (num) => {
  let count = 0;
  while (num > 1) {
    count++;
    num /= 10;
  }
  return count;
};

const zeroDigitCount = (num) => {
  let count = 0,
    i,
    len = digitCount(num);
  for (i = 0; i < len; i++) {
    if (num % 10 == 0) count++;
    num = Math.floor(num / 10);
  }

  return count;
};

alert(zeroDigitCount(input));
